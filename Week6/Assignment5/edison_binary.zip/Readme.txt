
================================================================================================

----------------------------------------------------------
Edge Detection and Image SegmentatiON (EDISON) System v1.1
----------------------------------------------------------
Authors: Bogdan Georgescu, Chris M. Christoudias, (freeware) 2002
Robust Image Understanding Laboratory, Rutgers University

================================================================================================

The Windows graphical user interface version of EDISON is located in the parent directory. The command prompt version of the system is located in the 'command' directory for both UNIX and Windows.

Contact Information
-------------------------------------------------------------------------------------------------

Personal Contact Information
----------------------------

Email:

	cmch@caip.rutgers.edu		(Chris M. Christoudias)
	georgesc@caip.rutgers.edu	(Bogdan Georgescu)

Laboratory Contact Information
------------------------------

Laboratory Website:
	
	www.caip.rutgers.edu/riul/

================================================================================================
